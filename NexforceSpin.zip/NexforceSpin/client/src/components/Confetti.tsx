import { useEffect, useRef } from "react";

export function Confetti() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
    const confettiCount = 150;
    const container = containerRef.current;
    const confettiElements: HTMLDivElement[] = [];
    
    for (let i = 0; i < confettiCount; i++) {
      const confetti = document.createElement('div');
      
      // Style the confetti
      confetti.style.position = 'fixed';
      confetti.style.zIndex = '1000';
      confetti.style.width = `${Math.random() * 10 + 5}px`;
      confetti.style.height = `${Math.random() * 10 + 5}px`;
      confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      confetti.style.left = `${Math.random() * 100}vw`;
      confetti.style.pointerEvents = 'none';
      confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
      
      // Add animation
      confetti.animate(
        [
          { 
            transform: 'translateY(-100vh) rotate(0deg)', 
            opacity: 1 
          },
          { 
            transform: 'translateY(100vh) rotate(360deg)', 
            opacity: 0 
          }
        ], 
        {
          duration: Math.random() * 3000 + 2000,
          delay: Math.random() * 2000,
          fill: 'forwards',
          easing: 'linear'
        }
      );
      
      container.appendChild(confetti);
      confettiElements.push(confetti);
    }
    
    // Clean up
    return () => {
      confettiElements.forEach(element => {
        if (element.parentNode) {
          element.parentNode.removeChild(element);
        }
      });
    };
  }, []);
  
  return <div ref={containerRef} />;
}
