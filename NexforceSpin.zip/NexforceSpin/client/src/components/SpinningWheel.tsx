import { useState, useRef, useEffect } from "react";
import { wheelConfig } from "@/lib/wheelConfig";
import { ResultModal } from "@/components/ResultModal";
import { Confetti } from "@/components/Confetti";

export function SpinningWheel() {
  const [isSpinning, setIsSpinning] = useState(false);
  const [selectedSector, setSelectedSector] = useState<typeof wheelConfig.sectors[0] | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [rotation, setRotation] = useState(0);
  const svgRef = useRef<SVGSVGElement>(null);
  const wheelSize = 500; // Size of the wheel in pixels
  const centerX = wheelSize / 2;
  const centerY = wheelSize / 2;
  const radius = wheelSize / 2 - 10; // Slightly smaller to fit inside container

  const spinWheel = () => {
    if (isSpinning) return;
    
    setIsSpinning(true);
    
    // Random number of spins between min and max
    const spins = wheelConfig.minSpins + Math.random() * (wheelConfig.maxSpins - wheelConfig.minSpins);
    
    // Random end sector
    const targetSectorIndex = Math.floor(Math.random() * wheelConfig.sectors.length);
    const selected = wheelConfig.sectors[targetSectorIndex];
    setSelectedSector(selected);
    
    // Calculate target rotation
    const sectorAngle = 360 / wheelConfig.sectors.length;
    const targetRotation = 360 * spins + (360 - (targetSectorIndex * sectorAngle));
    
    // Apply rotation
    const newRotation = rotation + targetRotation;
    setRotation(newRotation);
    
    // Reset state after spin completes
    setTimeout(() => {
      setIsSpinning(false);
      setShowModal(true);
      
      if (selected.type === 'prize') {
        setShowConfetti(true);
      }
    }, wheelConfig.spinDuration);
  };

  const closeResult = () => {
    setShowModal(false);
    setShowConfetti(false);
  };

  // Creates the path for a slice
  const createSlicePath = (startAngle: number, endAngle: number): string => {
    // Convert angles to radians and calculate coordinates
    const startAngleRad = (startAngle * Math.PI) / 180;
    const endAngleRad = (endAngle * Math.PI) / 180;
    
    // Calculate the x and y coordinates of the start and end points
    const startX = centerX + radius * Math.cos(startAngleRad);
    const startY = centerY + radius * Math.sin(startAngleRad);
    const endX = centerX + radius * Math.cos(endAngleRad);
    const endY = centerY + radius * Math.sin(endAngleRad);
    
    // Create the path with an arc
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
    
    return `M ${centerX} ${centerY} 
            L ${startX} ${startY} 
            A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY} 
            Z`;
  };

  // Calculate text position on a slice
  const calculateTextPosition = (angle: number): { x: number; y: number } => {
    // We position the text at 75% of the distance from center to edge
    const textRadius = radius * 0.65;
    const angleRad = (angle * Math.PI) / 180;
    
    return {
      x: centerX + textRadius * Math.cos(angleRad),
      y: centerY + textRadius * Math.sin(angleRad)
    };
  };

  // Create wheel sectors and text
  const renderWheel = () => {
    const numSectors = wheelConfig.sectors.length;
    const sectorAngle = 360 / numSectors;
    
    return wheelConfig.sectors.map((sector, index) => {
      const startAngle = index * sectorAngle;
      const endAngle = (index + 1) * sectorAngle;
      const midAngle = startAngle + sectorAngle / 2;
      
      // Position for the text
      const textPos = calculateTextPosition(midAngle);
      const textRotation = midAngle > 90 && midAngle < 270 ? midAngle + 180 : midAngle;
      
      return (
        <g key={index}>
          {/* Sector slice */}
          <path
            d={createSlicePath(startAngle, endAngle)}
            fill={sector.color}
            stroke="#ffffff"
            strokeWidth="1"
          />
          
          {/* Text on slice */}
          <text
            x={textPos.x}
            y={textPos.y}
            fill="#333333"
            fontSize="12"
            fontWeight="bold"
            textAnchor="middle"
            transform={`rotate(${textRotation}, ${textPos.x}, ${textPos.y})`}
          >
            <tspan x={textPos.x} dy="0">{sector.text.split(' ').slice(0, 2).join(' ')}</tspan>
            {sector.text.split(' ').length > 2 && (
              <tspan x={textPos.x} dy="14">{sector.text.split(' ').slice(2, 4).join(' ')}</tspan>
            )}
            {sector.text.split(' ').length > 4 && (
              <tspan x={textPos.x} dy="14">{sector.text.split(' ').slice(4).join(' ')}</tspan>
            )}
          </text>
        </g>
      );
    });
  };

  return (
    <>
      <div className="wheel-container relative w-full max-w-md mx-auto mb-8">
        {/* SVG Wheel */}
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          viewBox={`0 0 ${wheelSize} ${wheelSize}`}
          className="wheel-svg"
          style={{ 
            transform: `rotate(${rotation}deg)`,
            transition: isSpinning ? `transform ${wheelConfig.spinDuration}ms cubic-bezier(0.17, 0.67, 0.28, 0.99)` : 'none'
          }}
        >
          {/* Background circle */}
          <circle
            cx={centerX}
            cy={centerY}
            r={radius}
            fill="white"
            stroke="#cccccc"
            strokeWidth="1"
          />
          
          {/* Wheel sections */}
          {renderWheel()}
        </svg>
        
        {/* Spinner Button */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="pointer-events-auto relative z-10 w-20 h-20 rounded-full bg-white shadow-lg flex items-center justify-center">
            <button 
              className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 text-white font-bold text-lg shadow-md hover:from-blue-600 hover:to-blue-800 focus:outline-none transform transition-transform active:scale-95"
              onClick={spinWheel}
              disabled={isSpinning}
            >
              Girar
            </button>
          </div>
        </div>
        
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-2 z-10">
          <div className="w-6 h-8 bg-red-500" style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }}></div>
        </div>
      </div>

      {/* Result Modal */}
      <ResultModal 
        isVisible={showModal} 
        sector={selectedSector}
        onClose={closeResult}
      />

      {/* Confetti */}
      {showConfetti && <Confetti />}

      <style>{`
        .wheel-container {
          aspect-ratio: 1 / 1;
          position: relative;
        }
        
        .wheel-svg {
          display: block;
          width: 100%;
          height: 100%;
        }
      `}</style>
    </>
  );
}
