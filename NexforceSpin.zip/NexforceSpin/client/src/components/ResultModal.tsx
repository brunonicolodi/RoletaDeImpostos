import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

interface ResultModalProps {
  isVisible: boolean;
  sector: {
    text: string;
    type: string;
    icon: string;
  } | null;
  onClose: () => void;
}

export function ResultModal({ isVisible, sector, onClose }: ResultModalProps) {
  const [opacity, setOpacity] = useState(false);
  const [scale, setScale] = useState(false);

  useEffect(() => {
    if (isVisible) {
      // Small delay to ensure animation works
      setTimeout(() => {
        setOpacity(true);
        setScale(true);
      }, 10);
    } else {
      setOpacity(false);
      setScale(false);
    }
  }, [isVisible]);

  if (!sector) return null;

  return (
    <div 
      className={`fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50 transition-opacity duration-300 ${opacity ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
    >
      <div className={`bg-white rounded-lg shadow-xl max-w-md w-full mx-4 transform transition-transform duration-300 ${scale ? 'scale-100' : 'scale-95'}`}>
        <div className="p-6">
          <div className="text-center text-5xl mb-4">{sector.icon}</div>
          <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">
            {sector.type === 'prize' ? 'Parabéns!' : 'Informação Fiscal'}
          </h2>
          <p className="text-lg text-center text-gray-700 mb-6">{sector.text}</p>
          <div className="flex justify-center space-x-4">
            <Button onClick={onClose} className="px-6 py-2">
              Fechar
            </Button>
            <Button onClick={() => {
              onClose();
              // Small delay before spinning again
              setTimeout(() => {
                document.querySelector('.wheel-container button')?.dispatchEvent(
                  new MouseEvent('click', { bubbles: true })
                );
              }, 200);
            }} className="px-6 py-2 bg-blue-600 hover:bg-blue-700">
              Girar Novamente
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
