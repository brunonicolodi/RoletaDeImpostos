import { SpinningWheel } from "@/components/SpinningWheel";

export default function Home() {
  return (
    <div className="bg-gradient-to-b from-gray-100 to-white min-h-screen flex flex-col items-center justify-center p-4">
      {/* Header */}
      <header className="text-center mb-6">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Roleta Fiscal Nexforce</h1>
      </header>

      {/* Spinning Wheel */}
      <SpinningWheel />

      {/* Footer */}
      <footer className="mt-auto text-center p-4 text-gray-600 text-sm">
        <p>© 2025 Nexforce. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}
