export const wheelConfig = {
  sectors: [
    { text: "Ganhou um Trident!", type: "prize", color: "#dde3ed", icon: "🎁" },
    { text: "Notion, Slack, Figma... com até 70% a mais", type: "info", color: "#e7eff8", icon: "💼" },
    { text: "Trident liberado!", type: "prize", color: "#f4f0ed", icon: "🎁" },
    { text: "CIDE: +10% em suporte ou treinamento", type: "info", color: "#dde3ed", icon: "💼" },
    { text: "Trident + Dica Fiscal", type: "prize", color: "#e7eff8", icon: "🎁" },
    { text: "IOF: +6,38% no cartão", type: "info", color: "#f4f0ed", icon: "💼" },
    { text: "Trident na mão, imposto no controle", type: "prize", color: "#dde3ed", icon: "🎁" },
    { text: "Nexwave: até 50% economia com segurança fiscal", type: "info", color: "#e7eff8", icon: "💼" },
    { text: "PIS/COFINS: +9,25% no seu SaaS", type: "info", color: "#f4f0ed", icon: "💼" },
    { text: "Fatura de US$1.000 vira R$7.000", type: "info", color: "#dde3ed", icon: "💼" },
    { text: "Pegue seu Trident!", type: "prize", color: "#e7eff8", icon: "🎁" },
    { text: "O Trident é seu!", type: "prize", color: "#f4f0ed", icon: "🎁" }
  ],
  spinDuration: 8000, // spin duration in ms
  minSpins: 2, // minimum number of full rotations
  maxSpins: 5  // maximum number of full rotations
};
